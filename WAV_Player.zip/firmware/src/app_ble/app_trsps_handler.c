/*******************************************************************************
  Application BLE Profile Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app_trsps_handler.c

  Summary:
    This file contains the Application BLE functions for this project.

  Description:
    This file contains the Application BLE functions for this project.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2018 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <string.h>
#include "stdint.h"
#include "ble_trsps.h"
#include "osal/osal_freertos_extend.h"
#include "definitions.h"

#include "../WAV_Player.X/myapp.h"                              // KJD ADDED

#define APP_LED_RED_ON          GPIOB_REGS->GPIO_PORTSET = 0x01;
#define APP_LED_RED_OFF         GPIOB_REGS->GPIO_PORTCLR = 0x01;
#define APP_LED_GREEN_ON        GPIOB_REGS->GPIO_PORTSET = 0x08;
#define APP_LED_GREEN_OFF       GPIOB_REGS->GPIO_PORTCLR = 0x08;
#define APP_LED_BLUE_ON         GPIOB_REGS->GPIO_PORTSET = 0x20;
#define APP_LED_BLUE_OFF        GPIOB_REGS->GPIO_PORTCLR = 0x20;


// *****************************************************************************
// *****************************************************************************
// Section: Global Variables
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Functions
// *****************************************************************************
// *****************************************************************************

void APP_TrspsEvtHandler(BLE_TRSPS_Event_T *p_event)
{
    switch(p_event->eventId)
    {
        case BLE_TRSPS_EVT_CTRL_STATUS:
        {
            /* TODO: implement your application code.*/
        }
        break;
        
        case BLE_TRSPS_EVT_TX_STATUS:
        {
            /* TODO: implement your application code.*/
        }
        break;

        case BLE_TRSPS_EVT_CBFC_ENABLED:
        {
            /* TODO: implement your application code.*/
        }
        break;
        
        case BLE_TRSPS_EVT_CBFC_CREDIT:
        {
            /* TODO: implement your application code.*/
        }
        break;
        
        //---------------------------------------------------------------------- START APP CODE HERE - KJD
        // BLE Data is Received here
        //----------------------------------------------------------------------                
        case BLE_TRSPS_EVT_RECEIVE_DATA:
            {
            uint16_t data_len;
            uint8_t *data;

            // Retrieve received data length
            BLE_TRSPS_GetDataLength(p_event->eventField.onReceiveData.connHandle, &data_len);

            // Allocate memory according to data length
            data = OSAL_Malloc(data_len);

            if(data == NULL)
                break;

            // Retrieve received data
            BLE_TRSPS_GetData(p_event->eventField.onReceiveData.connHandle, data);

            // Should have the received data packet here ready to parse
            switch(data[0])
                {
                //------------------------------------------------------
                // Speed Commands
                case 'S':
                    if(data[1] == 'U')
                        {
                        SERCOM0_USART_Write((void*)"Speed Up Command\n", 17);	// Speed Up
                        APP_LED_RED_ON;
                        }
                    if(data[1] == 'D')
                        {
                        SERCOM0_USART_Write((void*)"Speed Down Command\n", 19); // Speed Down                    
                        APP_LED_RED_OFF;
                        }
                    break;
                //------------------------------------------------------
                // Mode Commands
                case 'M':
                    if(data[1] == 'R')
              			SERCOM0_USART_Write((void*)"Rock Mode Command\n", 18);	// Mode is Rock
                    if(data[1] == 'G')
              			SERCOM0_USART_Write((void*)"Glide Mode Command\n", 19);	// Mode is Glide
                    if(data[1] == 'S')
              			SERCOM0_USART_Write((void*)"Swing Mode Command\n", 19);	// Mode is Swing
                    if(data[1] == 'C')
              			SERCOM0_USART_Write((void*)"Cradle Mode Command\n", 20);// Mode is Cradle
                    break;
                //------------------------------------------------------
                // Play Sound Commands    
                case 'P':
                    if(data[1] == 'M')
                        {
                        myAPP_Tasks();                                                  // Call the function to play music
                        SERCOM0_USART_Write((void*)"Play Music Command\n", 19);			// Play Music
                        }
                    if(data[1] == 'W')
                        {                       // Stop playing music
                        Stop_WAV();
                        SERCOM0_USART_Write((void*)"Play White Noise Command\n", 25);	// Play White noise
                        }
                    if(data[1] == 'N')
                        {                       // Stop playing music
                        Stop_WAV();
              			SERCOM0_USART_Write((void*)"Play Nature Sounds Command\n", 27);	// Play Nature sounds
                        }
                    break;
                //------------------------------------------------------
                // Volume Commands    
                case 'L':
                    if(data[1] == 'U')
                        {
              			SERCOM0_USART_Write((void*)"Volume/Level Up Command\n", 24);	// Volume Up
                          APP_LED_BLUE_ON;                        
                        }
                    if(data[1] == 'D')
                        {
                  		SERCOM0_USART_Write((void*)"Volume/Level Down Command\n", 26);	// Volume Down                    
                          APP_LED_BLUE_OFF;                        
                        }
                    break;                            
                }                
            
            // Output received data to UART
//            SERCOM0_USART_Write(data, data_len);

            // Free memory
            OSAL_Free(data);
        }
        break;
        
        case BLE_TRSPS_EVT_VENDOR_CMD:
        {
            /* TODO: implement your application code.*/
        }
        break;
       
        default:
        break;
    }
}