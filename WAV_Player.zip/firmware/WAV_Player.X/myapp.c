//------------------------------------------------------------------------------
// WAV Player Code for the Chimera Curiosity Board
// 6/29/2022 - Keith Donadio    
//------------------------------------------------------------------------------
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "../WAV_Player.X/myapp.h"

//------------------------------------------------------------------------------
// Defines for LED control
#define APP_LED_RED_ON          GPIO_PinSet(GPIO_PIN_RB0);      
#define APP_LED_RED_OFF         GPIO_PinClear(GPIO_PIN_RB0);    
#define APP_LED_GREEN_ON        GPIO_PinSet(GPIO_PIN_RB3);
#define APP_LED_GREEN_OFF       GPIO_PinClear(GPIO_PIN_RB3);
#define APP_LED_BLUE_ON         GPIO_PinSet(GPIO_PIN_RB5);
#define APP_LED_BLUE_OFF        GPIO_PinClear(GPIO_PIN_RB5);
#define SWITCH_Get()            ((GPIO_PortRead(GPIO_PORT_B) >> 4) & 0x1)
#define SIZEOF(a)               sizeof(a) / sizeof(a[0])

//------------------------------------------------------------------------------
// Global Variables
const uint32_t sample_rate = 8000;      // Sample rate of the sound table. 

//------------------------------------------------------------------------------
// Embedded wave file sound samples. 
//  1 - Use Audacity to open the wav file
//  2 - Re-sample at 8KHz Mono format 
//  3 - Export as 8-bit unsigned raw file (do not use 8-bit signed)
//  4 - Use bin2c to convert into a C array
//  5 - Edit the C file to remove the header and curly braces 
//  6 - Include file below
//

//------------------------------------------------------------------------------
// Song Selection #1
const uint8_t S1[] = {    
    // 8-bit files that are working
//	#include "Mario_8bit.c"			// GOOD		
	#include "twinkle.c"			// GOOD
//	#include "440Hz_Sine.c"			// GOOD
//	#include "fur_elise.c"			// GOOD
    
    // 16-bit files that are working
//	#include "Mario_16bit.c"		// GOOD
//	#include "Fur_Elise_16bit.c"	// GOOD    
};

//------------------------------------------------------------------------------
// Song Selection #2
const uint8_t S2[] = {    
	#include "Mario_8bit.c"			
};

//------------------------------------------------------------------------------
// Song Selection #3
const uint8_t S3[] = {    
	#include "fur_elise.c"			
};

const uint8_t *ptr;         // Pointer to the current selected song array
uint8_t song_select;        // Current song selection
uint32_t song_length;       // Number of samples in the array
uint32_t song_index;        // Index into the song array

//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------

void myAPP_Initialize(void)
{
    GPIO_PinOutputEnable(GPIO_PIN_RB2);             // Testing +++++
    GPIO_PinToggle(GPIO_PIN_RB2);
    
    // GPIO register initialization for LED control.
    GPIOB_REGS->GPIO_ANSEL = GPIOB_REGS->GPIO_ANSEL & 0xFFFFFFD6;
    GPIOB_REGS->GPIO_TRIS = GPIOB_REGS->GPIO_TRIS & 0xFFFFFFD6;
    GPIOB_REGS->GPIO_PORTCLR = 0x29;    
    
    /* Disable JTAG since at least one of its pins is configured for Non-JTAG function */
    // Need this to control Blue LED on PB5
    CFG_REGS->CFG_CFGCON0CLR = CFG_CFGCON0_JTAGEN_Msk;
    //    
//    GPIO_ANSEL_ANS0(0);
//    GPIO_ANSEL_ANS3(0);
//    GPIO_ANSEL_ANS5(0);    
    //
//    GPIO_PinOutputEnable(GPIO_PIN_RB0);             // Red LED as output
//    GPIO_PinOutputEnable(GPIO_PIN_RB3);             // Green LED as output
//    GPIO_PinOutputEnable(GPIO_PIN_RB5);             // Blue LED as output
    //
//    GPIO_PinClear(GPIO_PIN_RB0);                    // Red LED is off    
//    GPIO_PinClear(GPIO_PIN_RB3);                    // Green LED is off
//    GPIO_PinClear(GPIO_PIN_RB5);                    // Blue LED is off
    //
    TC3_TimerCallbackRegister(TC3_Ticker, 0);           // Interrupt handler callback
    //
    TCC0_REGS->TCC_CTRLBCLR = TCC_CTRLBCLR_LUPD(1);     // Enable double buffering
    TCC0_REGS->TCC_CC[0] = 0;                           // PWM CH 0 output is off    
    TCC0_REGS->TCC_CC[1] = 0;                           // PWM CH 1 output is off        
    TCC0_PWMStart();                                    // Start the PWM
    //	
    song_select = 1;
    //
}


void myAPP_Tasks(void)
{
    //
//    GPIO_PinToggle(GPIO_PIN_RB2);        

    // Determine song selection here
    switch(song_select)
        {
        case 1:         // Selection S1
            song_length = SIZEOF(S1);   
            ptr = S1;
            song_select = 2;                  
            break;
        case 2:         // Selection S2
            song_length = SIZEOF(S2);   
            ptr = S2;                    
            song_select = 3;                                        
            break;
        case 3:         // Selection S3
            song_length = SIZEOF(S3);   
            ptr = S3;                    
            song_select = 1;                                        
            break;
        }
    //
    song_index = 0;
    APP_LED_GREEN_ON;       // Turn on Green LED   
    TC3_TimerStart();       // Start the sample clock
    //
}

//------------------------------------------------------------------------------
// TC3 Callback Interrupt (8KHz sample rate))
void TC3_Ticker(TC_TIMER_STATUS status, uintptr_t context)
{
    GPIO_PinToggle(GPIO_PIN_RB2);        

    // Loop through all sound samples in the array
    if(song_index < song_length)               
        {
        // 8-bit version
        TCC0_REGS->TCC_CCBUF[0] = ptr[song_index++];      // LSB is 8-bit data
        TCC0_REGS->TCC_CCBUF[1] = 0;                      // MSB is always zero for 8-bit samples

        // 16-bit version
//        TCC0_REGS->TCC_CCBUF[0] = (uint8_t)(wav_samples[i] & 0xFF);           // Write the LSB sample  Little Endian
//        TCC0_REGS->TCC_CCBUF[1] = (uint8_t)((wav_samples[i] >> 8) & 0xFF);    // Write the MSB sample
        //
//        TCC0_REGS->TCC_CCBUF[1] = (uint8_t)(wav_samples[i] & 0xFF);           // Write the LSB sample  Big Endian
//        TCC0_REGS->TCC_CCBUF[0] = (uint8_t)((wav_samples[i] >> 8) & 0xFF);    // Write the MSB sample            
        }
    else    // Song is over now set everything to an off state
        {
        APP_LED_GREEN_OFF;                                  // Turn off Green LED           
        TC3_TimerStop();                                    // Stop the sample clock
		// Clear TCC0 compare B registers for the two 8-bit PWM channels
		TCC0_REGS->TCC_CCBUF[0] = 0;                        // Clear CCBUF0 for 0% D.C.
		TCC0_REGS->TCC_CCBUF[1] = 0;                        // Clear CCBUF1 for 0% D.C.
        }
    //
}

//------------------------------------------------------------------------------
// Microsecond delay
void __delay_uS(unsigned long int count)
{
    while(count-- > 0)
        {
        __asm("nop");           // 1
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 5
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 10
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 15
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 20
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 25
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 30
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 35
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 40
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 45
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 48
        __asm("nop");
        __asm("nop");           // 50
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 55     
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 59
        }
    //    
}

//------------------------------------------------------------------------------
// Millisecond delay
void __delay_mS(unsigned short int ms )
{
    while (ms--)
        {
        __delay_uS(1000);
        }
}

void Stop_WAV(void)
{
    APP_LED_RED_OFF;                                // Turn off Red LED           
  
    TC3_TimerStop();
    
    // Clear TCC0 compare B registers for the two 8-bit PWM channels
    TCC0_REGS->TCC_CCBUF[0] = 0;					// Clear CCB0 for 0% D.C.
    TCC0_REGS->TCC_CCBUF[1] = 0;					// Clear CCB1 for 0% D.C.            			
}
                        
// EOF
